
import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

// Last .env
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = process.env.DB_FILE || 'data.db';
const ADMIN_API_KEY = process.env.ADMIN_API_KEY || '';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

let db;

async function initDb(){
  db = await open({ filename: DB_FILE, driver: sqlite3.Database });
  await db.exec(`
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS carts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE, -- kort kode/nummer på vogn
      label TEXT NOT NULL,       -- visningsnavn
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cart_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      action TEXT NOT NULL CHECK(action IN ('out','in')),
      ts_utc TEXT NOT NULL,
      note TEXT,
      FOREIGN KEY(cart_id) REFERENCES carts(id),
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
  `);
}

function requireAdmin(req, res, next){
  const key = req.header('x-admin-key');
  if(!ADMIN_API_KEY){
    // Hvis ikke satt, slipp gjennom for enkelhets skyld (lab/oppsett)
    return next();
  }
  if(key === ADMIN_API_KEY){
    return next();
  }
  return res.status(401).json({ error: 'Ugyldig eller manglende admin-nøkkel' });
}

// Helse
app.get('/api/health', (req, res)=>{
  res.json({ ok: true });
});

// Users
app.get('/api/users', async (req, res)=>{
  const rows = await db.all('SELECT * FROM users WHERE active=1 ORDER BY name');
  res.json(rows);
});

app.post('/api/users', requireAdmin, async (req, res)=>{
  const { name } = req.body;
  if(!name) return res.status(400).json({ error: 'Mangler navn' });
  try{
    const result = await db.run('INSERT INTO users(name, active) VALUES(?,1)', [name.trim()]);
    const row = await db.get('SELECT * FROM users WHERE id=?', [result.lastID]);
    res.status(201).json(row);
  } catch(err){
    if(String(err).includes('UNIQUE')){
      return res.status(409).json({ error: 'Navn finnes allerede' });
    }
    res.status(500).json({ error: 'Kunne ikke opprette bruker' });
  }
});

app.delete('/api/users/:id', requireAdmin, async (req, res)=>{
  const { id } = req.params;
  await db.run('UPDATE users SET active=0 WHERE id=?', [id]);
  res.json({ ok: true });
});

// Carts
app.get('/api/carts', async (req, res)=>{
  const rows = await db.all('SELECT * FROM carts WHERE active=1 ORDER BY label');
  res.json(rows);
});

app.post('/api/carts', requireAdmin, async (req, res)=>{
  const { code, label } = req.body;
  if(!code || !label) return res.status(400).json({ error: 'Mangler code/label' });
  try{
    const result = await db.run('INSERT INTO carts(code, label, active) VALUES(?,?,1)', [code.trim(), label.trim()]);
    const row = await db.get('SELECT * FROM carts WHERE id=?', [result.lastID]);
    res.status(201).json(row);
  } catch(err){
    if(String(err).includes('UNIQUE')){
      return res.status(409).json({ error: 'Vognkode finnes allerede' });
    }
    res.status(500).json({ error: 'Kunne ikke opprette vogn' });
  }
});

app.delete('/api/carts/:id', requireAdmin, async (req, res)=>{
  const { id } = req.params;
  await db.run('UPDATE carts SET active=0 WHERE id=?', [id]);
  res.json({ ok: true });
});

// Transactions (inn/ut)
app.post('/api/transactions', async (req, res)=>{
  const { cart_id, user_id, action, ts_utc, note } = req.body;
  if(!cart_id || !user_id || !action){
    return res.status(400).json({ error: 'Mangler cart_id/user_id/action' });
  }
  const ts = ts_utc || new Date().toISOString();
  if(!['in','out'].includes(action)){
    return res.status(400).json({ error: 'action må være in|out' });
  }
  try{
    await db.run('INSERT INTO transactions(cart_id,user_id,action,ts_utc,note) VALUES(?,?,?,?,?)', [cart_id, user_id, action, ts, note || null]);
    res.status(201).json({ ok: true });
  } catch(err){
    res.status(500).json({ error: 'Kunne ikke lagre transaksjon' });
  }
});

// Status for alle vogner: siste transaksjon
app.get('/api/status', async (req, res)=>{
  const carts = await db.all('SELECT * FROM carts WHERE active=1 ORDER BY label');
  const statusList = [];
  for(const c of carts){
    const last = await db.get(`SELECT t.*, u.name as user_name FROM transactions t 
      JOIN users u ON u.id=t.user_id 
      WHERE t.cart_id=? ORDER BY t.ts_utc DESC, t.id DESC LIMIT 1`, [c.id]);
    let status = 'Inne';
    let since = null;
    let by = null;
    if(last){
      if(last.action === 'out') { status = 'Ute'; since = last.ts_utc; by = last.user_name; }
      else { status = 'Inne'; since = last.ts_utc; by = last.user_name; }
    }
    statusList.push({ ...c, status, since, by });
  }
  res.json(statusList);
});

// Rapport
app.get('/api/report', async (req, res)=>{
  const { from, to } = req.query; // ISO
  let where = [];
  let params = [];
  if(from){ where.push('t.ts_utc >= ?'); params.push(from); }
  if(to){ where.push('t.ts_utc <= ?'); params.push(to); }
  const whereSql = where.length ? ('WHERE ' + where.join(' AND ')) : '';
  const rows = await db.all(`
    SELECT t.id, t.ts_utc, t.action, t.note, c.code as cart_code, c.label as cart_label, u.name as user_name
    FROM transactions t
    JOIN carts c ON c.id=t.cart_id
    JOIN users u ON u.id=t.user_id
    ${whereSql}
    ORDER BY t.ts_utc DESC, t.id DESC
  `, params);
  res.json(rows);
});

// Fallback: server index.html (SPA-aktig navigasjon)
app.get('*', (req, res)=>{
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

initDb().then(()=>{
  app.listen(PORT, ()=>{
    console.log(`Server kjører på http://localhost:${PORT}`);
  });
});
