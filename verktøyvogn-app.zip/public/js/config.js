
// Sett base-URL til API. Når frontend serveres fra samme Express-app, bruk relativ sti.
const API_BASE = '';
