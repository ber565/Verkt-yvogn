
# Verktøyvogn-app

Enkel webapp for å registrere verktøyvogner inn/ut, med admin-side, status, rapporter og QR-støtte. Laget med Express + SQLite og ren HTML/JS.

## Funksjoner
- **Registrering**: Velg vogn, bruker, dato/klokkeslett (med "Nå"-knapp) og registrer **Ut** eller **Inn**.
- **QR**: Generer QR-kode for hver vogn. Skann med kamera for å velge riktig vogn.
- **Admin**: Legg til/slett vogner og brukere (beskyttet med admin-nøkkel).
- **Status**: Se oversikt over alle vogner og om de er Inne/Ute, med sist-endret og av hvem.
- **Rapporter**: Filtrer på dato og eksporter CSV.

## Kom i gang (lokalt)
1. Installer Node.js (18+).
2. Klon repoet og gå inn i mappen:
   ```bash
   npm install
   cp .env.example .env
   # rediger .env og sett ADMIN_API_KEY
   npm run start
   ```
3. Åpne `http://localhost:3000` i nettleser.

## Deploy
- **GitHub**: Push hele mappen som et repo.
- **Drift**: Kjør som en enkel Node-app hos f.eks. Render, Railway, Azure App Service eller en lokal server/VM. Sørg for at `DB_FILE` peker på vedvarende lagring.
- **GitHub Pages**: Denne appen serverer frontend fra Express. Hvis du vil serve frontend statisk fra GitHub Pages, må du endre `API_BASE` i `public/js/config.js` til URL-en til din backend (f.eks. https://din-app.onrender.com).

## Sikkerhet
- Admin-endepunkter krever `x-admin-key` som må stemme med `ADMIN_API_KEY` i `.env`.
- Vanlige registreringer (inn/ut) er åpne (for enkel bruk i verksted). Legg på autentisering hvis nødvendig.

## API (kort)
- `GET /api/users`, `POST /api/users` (admin), `DELETE /api/users/:id` (admin)
- `GET /api/carts`, `POST /api/carts` (admin), `DELETE /api/carts/:id` (admin)
- `POST /api/transactions`  body: `{ cart_id, user_id, action: 'in'|'out', ts_utc?, note? }`
- `GET /api/status`
- `GET /api/report?from=ISO&to=ISO`

## QR-format
Generert tekst: `https://<ditt-domene>/#cart=<ID>`.
Skanneren i registreringssiden tolker både denne URL-en og rå `ID`.

## Lisens
MIT
